import React from "react";

const DoctorCard = ({ doctor }) => (
  <div className="doctor-card" data-testid="doctor-card">
    <h3 data-testid="doctor-name">{doctor.name}</h3>
    <p data-testid="doctor-specialty">{doctor.speciality.join(", ")}</p>
    <p data-testid="doctor-experience">Experience: {doctor.experience} years</p>
    <p data-testid="doctor-fee">Fees: ₹{doctor.fees}</p>
  </div>
);

export default DoctorCard;
