import React from "react";

const specialties = [
  "General Physician", "Dentist", "Dermatologist", "Paediatrician", "Gynaecologist",
  "ENT", "Diabetologist", "Cardiologist", "Physiotherapist", "Endocrinologist",
  "Orthopaedic", "Ophthalmologist", "Gastroenterologist", "Pulmonologist", "Psychiatrist",
  "Urologist", "Dietitian/Nutritionist", "Psychologist", "Sexologist", "Nephrologist",
  "Neurologist", "Oncologist", "Ayurveda", "Homeopath"
];

const Filters = ({ filters, setFilters }) => {
  const handleModeChange = (e) => setFilters({ ...filters, consultation: e.target.value });
  const handleSortChange = (e) => setFilters({ ...filters, sort: e.target.value });
  const toggleSpecialty = (value) => {
    const updated = filters.specialties.includes(value)
      ? filters.specialties.filter((s) => s !== value)
      : [...filters.specialties, value];
    setFilters({ ...filters, specialties: updated });
  };

  return (
    <div className="filters">
      <h4 data-testid="filter-header-moc">Consultation Mode</h4>
      <label><input type="radio" value="Video Consult" data-testid="filter-video-consult"
        checked={filters.consultation === "Video Consult"} onChange={handleModeChange} /> Video Consult</label>
      <label><input type="radio" value="In Clinic" data-testid="filter-in-clinic"
        checked={filters.consultation === "In Clinic"} onChange={handleModeChange} /> In Clinic</label>

      <h4 data-testid="filter-header-speciality">Speciality</h4>
      {specialties.map((spec) => (
        <label key={spec}>
          <input type="checkbox" data-testid={`filter-specialty-${spec.replace(/[/ ]/g, "-")}`}
            checked={filters.specialties.includes(spec)} onChange={() => toggleSpecialty(spec)} /> {spec}
        </label>
      ))}

      <h4 data-testid="filter-header-sort">Sort</h4>
      <label><input type="radio" name="sort" value="fees" data-testid="sort-fees"
        checked={filters.sort === "fees"} onChange={handleSortChange} /> Fees</label>
      <label><input type="radio" name="sort" value="experience" data-testid="sort-experience"
        checked={filters.sort === "experience"} onChange={handleSortChange} /> Experience</label>
    </div>
  );
};

export default Filters;
