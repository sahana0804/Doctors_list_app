import React, { useState } from "react";

const SearchBar = ({ doctors, query, setQuery }) => {
  const [showSuggestions, setShowSuggestions] = useState(false);

  const suggestions = query
    ? doctors.filter((doc) => doc.name.toLowerCase().includes(query.toLowerCase())).slice(0, 3)
    : [];

  const handleSelect = (name) => {
    setQuery(name);
    setShowSuggestions(false);
  };

  return (
    <div className="search-bar">
      <input data-testid="autocomplete-input" value={query} onChange={(e) => {
        setQuery(e.target.value);
        setShowSuggestions(true);
      }} placeholder="Search doctors..." />
      {showSuggestions && suggestions.length > 0 && (
        <ul className="suggestions">
          {suggestions.map((s, i) => (
            <li key={i} data-testid="suggestion-item" onClick={() => handleSelect(s.name)}>{s.name}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchBar;
