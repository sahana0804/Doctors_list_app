import { useLocation, useNavigate } from 'react-router-dom';

export const useQueryParams = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const setQueryParams = (params) => {
    const searchParams = new URLSearchParams(params);
    navigate({ search: searchParams.toString() }, { replace: true });
  };

  const getQueryParams = () => {
    return Object.fromEntries(new URLSearchParams(location.search));
  };

  return { setQueryParams, getQueryParams };
};