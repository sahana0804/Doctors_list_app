import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, useLocation, useNavigate } from "react-router-dom";
import SearchBar from "./components/SearchBar";
import Filters from "./components/Filters";
import DoctorCard from "./components/DoctorCard";
import { fetchDoctors } from "./utils/api";

const AppContent = () => {
  const [doctors, setDoctors] = useState([]);
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState({
    consultation: "",
    specialties: [],
    sort: ""
  });

  const location = useLocation();
  const navigate = useNavigate();

  const syncQueryToState = () => {
    const params = new URLSearchParams(location.search);
    const query = params.get("q") || "";
    const consultation = params.get("consultation") || "";
    const specialties = params.getAll("specialty");
    const sort = params.get("sort") || "";
    setQuery(query);
    setFilters({ consultation, specialties, sort });
  };

  const updateURL = (newFilters, queryValue) => {
    const params = new URLSearchParams();
    if (queryValue) params.set("q", queryValue);
    if (newFilters.consultation) params.set("consultation", newFilters.consultation);
    newFilters.specialties.forEach((s) => params.append("specialty", s));
    if (newFilters.sort) params.set("sort", newFilters.sort);
    navigate({ search: params.toString() });
  };

  useEffect(() => {
    fetchDoctors().then(setDoctors);
  }, []);

  useEffect(() => {
    syncQueryToState();
  }, [location.search]);

  useEffect(() => {
    let result = [...doctors];
    if (query) result = result.filter((doc) => doc.name.toLowerCase().includes(query.toLowerCase()));
    if (filters.consultation) result = result.filter((doc) => doc.mode === filters.consultation);
    if (filters.specialties.length)
      result = result.filter((doc) =>
        filters.specialties.every((f) => doc.speciality.includes(f))
      );
    if (filters.sort === "fees") result.sort((a, b) => a.fees - b.fees);
    if (filters.sort === "experience") result.sort((a, b) => b.experience - a.experience);
    setFilteredDoctors(result);
  }, [filters, query, doctors]);

  return (
    <div className="container">
      <SearchBar doctors={doctors} query={query} setQuery={(q) => {
        updateURL(filters, q);
      }} />
      <Filters filters={filters} setFilters={(newFilters) => {
        updateURL(newFilters, query);
      }} />
      <div className="doctor-list">
        {filteredDoctors.map((doctor) => (
          <DoctorCard key={doctor.name} doctor={doctor} />
        ))}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
